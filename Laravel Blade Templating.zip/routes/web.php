<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/* Routes to views */
Route::get( '/',                   'TodoController@homeView'  );
Route::get( '/home',               'TodoController@homeView'  );
Route::get( '/about',              'TodoController@aboutView' );
Route::get( '/add',                'TodoController@addView'   );
// Don't put spaces within the {} - Laravel doesn't like that!
Route::get( '/editView/{todo_id}', 'TodoController@editView'  );
Route::get( '/list',               'TodoController@listView'  );

/* Routes for form submissions */
// Form submissions are limited to post and get, otherwise we'd use the proper HTTP methods
// AJAX allows us to use all the methods
// Add can use "PUT"
Route::post( '/add',               'TodoController@add'       );
// Edit can use "UPDATE"
Route::post( '/edit/{todo_id}',    'TodoController@edit'      );
// Delete can use "DELETE"
// Actually a link on the page - must make sure we're using get instead of post
Route::get( '/delete/{todo_id}',   'TodoController@delete'    );
