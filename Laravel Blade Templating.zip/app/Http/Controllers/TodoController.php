<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\TodoModel;
use App\TodoTypeModel;

class TodoController extends Controller
{
    /**
     * Load the "Home" page.
     *
     * @return mixed
     */
    public function homeView() {

        return view( 'index' );
    }

    /**
     * Load the "About" page.
     *
     * @return mixed
     */
    public function aboutView() {

        return view( 'about' );
    }

    /**
     * List all existing todo list items.
     *
     * @return mixed
     */
    public function listView() {

        $page_data[ 'todos' ] = TodoModel::all();

        return view( 'list', $page_data );
    }

    /**
     * Create a new todo list item.
     *
     * @return mixed
     */
    public function addView() {

        $page_data[ 'types' ] = TodoTypeModel::get()->toArray();

        return view( 'add', $page_data );
    }

    /**
     * Edit a todo list item.
     *
     * @param $todo_id
     * @return mixed
     */
    public function editView( $todo_id ) {

        $page_data[ 'todo' ] = TodoModel::find( $todo_id )->toArray();
        $page_data[ 'types' ] = TodoTypeModel::get()->toArray();

        return view( 'edit', $page_data );
    }

    /**
     * Creates the todo list item in the database.
     */
    public function add( Request $request ) {

        TodoModel::create( [
            'title' => $request->input( 'title', '' ),
            'note' => $request->input( 'note', '' ),
            'type_id' => $request->input( 'type_id', 0 )
        ] );

        // We're not loading a view, we're actually redirecting to another view.
        return redirect( '/list' );
    }

    /**
     * Updates the todo list item in the database.
     *
     * @param $todo_id
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function edit( Request $request, $todo_id ) {

        $model = TodoModel::find( $todo_id );

        // Make the changes.
        $model->title = $request->input( 'title', '' );
        $model->note = $request->input( 'note', '' );
        $model->type_id = $request->input( 'type_id', 0 );

        // Save the changes.
        $model->save();

        // We're not loading a view, we're actually redirecting to another view.
        return redirect( '/list' );
    }

    /**
     * Delete a todo list item from the database. There is no view for this action.
     *
     * @param $todo_id
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function delete( $todo_id ) {

        // Deleting the todo list item.
        TodoModel::find( $todo_id )->delete();

        // We're not loading a view, we're actually redirecting to another view.
        return redirect( '/list' );
    }
}
