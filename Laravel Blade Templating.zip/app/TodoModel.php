<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TodoModel extends Model
{
    protected $table = 'todos';

    protected $guarded = [ 'id', 'updated_at', 'created_at' ];

    protected $fillable = [ 'title', 'note', 'type_id' ];

    /**
     * Our todo list item model has a single todo type.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function type() {
        return $this->belongsTo( 'App\TodoTypeModel' );
    }
}
