<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TodoTypeModel extends Model
{
    protected $table = 'todo_types';

    protected $guarded = [ 'id' ];

    protected $fillable = [ 'name' ];

    /**
     * Our todo type model belongs to many todo list item models.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    protected function todos() {
        return $this->hasMany( 'App\TodoModel' );
    }
}
