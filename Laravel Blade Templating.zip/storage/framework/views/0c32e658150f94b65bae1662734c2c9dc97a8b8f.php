<?php $__env->startSection( 'title', 'Home' ); ?>
<?php $__env->startSection( 'content' ); ?>
    <h1>Index</h1>
    <p>This is the index page.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make( 'wrapper.wrapper' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>