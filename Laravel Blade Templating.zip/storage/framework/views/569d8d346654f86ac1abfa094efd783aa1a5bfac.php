<?php $__env->startSection( 'title', 'About' ); ?>
<?php $__env->startSection( 'content' ); ?>
    <div>
        <h1>About</h1>
        <p>This is the child content for this page.</p>
    </div>
    <div>
        @parent
    </div>
    <div>
        @parent
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'wrapper.alternate' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>