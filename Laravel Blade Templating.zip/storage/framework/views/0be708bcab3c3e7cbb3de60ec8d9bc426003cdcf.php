<!DOCTYPE html>
<html>
    <head>
        <title>
            Todo List - <?php echo $__env->yieldContent( 'title' ); ?>
        </title>
        <link rel="stylesheet" type="text/css" href="/css/app.css" />
        <?php echo $__env->yieldPushContent( 'styles' ); ?>
    </head>
    <body>
    <?php echo $__env->make( 'sections.header' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <section class="todo-container">
        <?php echo $__env->make( 'sections.navigation' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <section class="main-content">
            <?php echo $__env->yieldContent( 'content' ); ?>
        </section>
    </section>
    <?php echo $__env->make( 'sections.footer' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>
</html>