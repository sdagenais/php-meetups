<div class="todo-list-item">
    <header>
        <h2><?php echo e(isset($todo[ 'title' ]) ? $todo[ 'title' ] : 'Todo'); ?></h2>
    </header>
    <section>
        <div class="todo-list-item-note">
            <p><?php echo e(isset($todo[ 'note' ]) ? $todo[ 'note' ] : 'No notes for this todo.'); ?></p>
        </div>
        <div class="todo-list-item-type">
            <p><?php echo e(isset($todo[ 'type' ][ 'name' ]) ? $todo[ 'type' ][ 'name' ] : 'None'); ?></p>
        </div>
    </section>
    <footer>
        <p><a href="/editView/<?php echo e($todo[ 'id' ]); ?>">Edit</a></p>
        <p><a href="/delete/<?php echo e($todo[ 'id' ]); ?>">Delete</a></p>
    </footer>
</div>