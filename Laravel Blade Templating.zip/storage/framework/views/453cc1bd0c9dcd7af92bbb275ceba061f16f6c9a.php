<?php $__env->startSection( 'title', 'List' ); ?>
<?php $__env->startPush( 'styles' ); ?>
<link rel="stylesheet" type="text/css" href="css/list.css" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection( 'content' ); ?>
    <div class="todo-list">
        <?php echo $__env->renderEach( 'partials.list_item', $todos, 'todo', 'partials.list_item_empty' ); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make( 'wrapper.wrapper' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>