<?php $__env->startSection( 'title', 'Home' ); ?>
<?php $__env->startPush( 'styles' ); ?>
    <link rel="stylesheet" type="text/css" href="/css/table.css" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection( 'content' ); ?>
    <form method="post" action="/add">
        <?php echo e(csrf_field()); ?>

        <table>
            <tbody>
                <tr>
                    <td>Title</td>
                    <td><input type="text" name="title" /></td>
                </tr>
                <tr>
                    <td>Note</td>
                    <td><input type="text" name="note" /></td>
                </tr>
                <tr>
                    <td>Type</td>
                    <td>
                        <select name="type_id">
                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <option value="<?php echo e($type[ 'id' ]); ?>"><?php echo e($type[ 'name' ]); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" name="submit" value="Add" />
                    </td>
                </tr>
            </tbody>
        </table>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make( 'wrapper.wrapper' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>