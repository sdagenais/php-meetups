<?php

use Illuminate\Database\Seeder;
use App\TodoModel;

class TodoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        TodoModel::create( [
            'title' => 'Book',
            'note'  => 'Write a book.',
            'type_id' => 1
        ] );
    }
}
