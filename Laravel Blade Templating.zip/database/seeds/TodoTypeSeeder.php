<?php

use Illuminate\Database\Seeder;
use App\TodoTypeModel;

class TodoTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        TodoTypeModel::create( [
            'name' => 'Project'
        ] );
        TodoTypeModel::create( [
            'name' => 'Other'
        ] );
        TodoTypeModel::create( [
            'name' => 'Chores'
        ] );
    }
}
