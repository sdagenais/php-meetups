@extends( 'wrapper.wrapper' )
@section( 'title', 'Home' )
@push( 'styles' )
<link rel="stylesheet" type="text/css" href="/css/table.css" />
@endpush
@section( 'content' )
    <form method="post" action="/edit/{{ $todo[ 'id' ] }}">
        {{ csrf_field() }}
        <table>
            <tbody>
                <tr>
                    <td>Title</td>
                    <td><input type="text" name="title" value="{{ $todo[ 'title' ] or '' }}" /></td>
                </tr>
                <tr>
                    <td>Note</td>
                    <td><input type="text" name="note" value="{{ $todo[ 'note' ] or '' }}" /></td>
                </tr>
                <tr>
                    <td>Type</td>
                    <td>
                        <select name="type_id">
                            @foreach( $types as $type )
                                <option
                                    @if( $todo[ 'type_id' ] == $type[ 'id' ] )
                                        selected="selected"
                                    @endif
                                    value="{{ $type[ 'id' ] }}"
                                >{{ $type[ 'name' ] }}</option>
                            @endforeach
                        </select>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" name="submit" value="Update" />
                    </td>
                </tr>
            </tbody>
        </table>
    </form>
@endsection
