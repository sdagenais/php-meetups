<!DOCTYPE html>
<html>
    <head>
        <title>
            Todo List - @yield( 'title' )
        </title>
        <link rel="stylesheet" type="text/css" href="/css/app.css" />
        @stack( 'styles' )
    </head>
    <body>
    @include( 'sections.header' )
    <section class="todo-container">
        @include( 'sections.navigation' )
        <section class="main-content">
            @yield( 'content' )
        </section>
    </section>
    @include( 'sections.footer' )
    </body>
</html>