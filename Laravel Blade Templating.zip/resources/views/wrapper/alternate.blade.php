<!DOCTYPE html>
<html>
<head>
    <title>
        Todo List Alternate - @yield( 'title' )
    </title>
    <link rel="stylesheet" type="text/css" href="/css/app.css" />
    @stack( 'styles' )
</head>
<body>
@include( 'sections.header' )
<section class="todo-container">
    @include( 'sections.navigation' )
    <section class="main-content">
        @section( 'content' )
            <div>
                <p>Content follows.</p>
            </div>
        @show
    </section>
</section>
@include( 'sections.footer' )
</body>
</html>