@extends( 'wrapper.wrapper' )
@section( 'title', 'List' )
@push( 'styles' )
<link rel="stylesheet" type="text/css" href="css/list.css" />
@endpush
@section( 'content' )
    <div class="todo-list">
        @each( 'partials.list_item', $todos, 'todo', 'partials.list_item_empty' )
    </div>
@endsection