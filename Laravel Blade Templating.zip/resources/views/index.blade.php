@extends( 'wrapper.wrapper' )
@section( 'title', 'Home' )
@section( 'content' )
    <h1>Index</h1>
    <p>This is the index page.</p>
@endsection
