@extends( 'wrapper.wrapper' )
@section( 'title', 'Home' )
@push( 'styles' )
    <link rel="stylesheet" type="text/css" href="/css/table.css" />
@endpush
@section( 'content' )
    <form method="post" action="/add">
        {{ csrf_field() }}
        <table>
            <tbody>
                <tr>
                    <td>Title</td>
                    <td><input type="text" name="title" /></td>
                </tr>
                <tr>
                    <td>Note</td>
                    <td><input type="text" name="note" /></td>
                </tr>
                <tr>
                    <td>Type</td>
                    <td>
                        <select name="type_id">
                            @foreach( $types as $type )
                                <option value="{{ $type[ 'id' ] }}">{{ $type[ 'name' ] }}</option>
                            @endforeach
                        </select>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" name="submit" value="Add" />
                    </td>
                </tr>
            </tbody>
        </table>
    </form>
@endsection
