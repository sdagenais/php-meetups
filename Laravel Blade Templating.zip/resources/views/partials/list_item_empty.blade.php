<div class="todo-list-message">
    <header>
        <h2>There are no todo items to display.</h2>
    </header>
</div>