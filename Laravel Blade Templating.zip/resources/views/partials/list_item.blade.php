<div class="todo-list-item">
    <header>
        <h2>{{ $todo[ 'title' ] or 'Todo' }}</h2>
    </header>
    <section>
        <div class="todo-list-item-note">
            <p>{{ $todo[ 'note' ] or 'No notes for this todo.' }}</p>
        </div>
        <div class="todo-list-item-type">
            <p>{{ $todo[ 'type' ][ 'name' ] or 'None' }}</p>
        </div>
    </section>
    <footer>
        <p><a href="/editView/{{ $todo[ 'id' ] }}">Edit</a></p>
        <p><a href="/delete/{{ $todo[ 'id' ] }}">Delete</a></p>
    </footer>
</div>