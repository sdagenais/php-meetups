<?php
/*
 *
 * PHP Meetup: Tips and Tricks
 *
 */

/*
 * Examples of better debugging
 *
 * Of course, today, you're not limited to the lowly print_r() function. There are many people out
 * there who have created much better ways of looking at your data during debugging. Here are some
 * examples of debugging tools that you can use in PHP:
 *
 * Kint
 * http://raveren.github.io/kint/
 *
 * Debugging tool that looks really nice. Even integrates into different popular frameworks.
 *
 * Krumo
 * http://krumo.sourceforge.net/
 *
 * Similar in purpose to Kint, except that it may be faster to render (due to there not being much
 * formatting involved). No less clear, though.
 *
 * XDebug
 * https://xdebug.org/
 * https://xdebug.org/docs/
 *
 * Pretty much a whole suite of debugging features that you can use on your server. 
 */
?>

