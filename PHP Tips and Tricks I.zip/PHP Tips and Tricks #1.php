<?php
/*
 *
 * PHP Meetup: Tips and Tricks
 *
 */

$an_array = [
	'one' => 15,
	'two' => 17,
	'three' => 14
];

/*
 * echo
 * 
 * Of course, there is the echo statement that will allow you show stuff on the screen. However, 
 * this doesn't make it easy to show stuff on the screen if you've got an object or an array.
 * Looking at the example below, you can see how much work it is. This is a simple array, so
 * recursion or multiple levels of for loops are not necessary.
 * 
 * The echo statement is therefore only good for returning very small amounts of data - it wouldn't
 * be a good idea to return all the data from the $_SESSION[] or $_COOKIE[] globals.
 */

?>
<pre>
<?php
 for( $i = 0; i < count( $an_array ); i++ ) {
	 echo $an_array[ i ];
 }
?>
</pre>
<?php

/*
 * print_r() on HTML page
 *
 * The go-to function for printing information on screen quickly. You may also be familiar with
 * var_dump(). These are closely related.
 *
 * This is the way I normally use the function while debugging a website project. This will only
 * work if you are responding to requests with HTML that will be displayed directly on the screen.
 *
 * The "<pre>" element is used to render the line breaks that print_r generates when compiling the
 * data. In most situations, the text nodes contained within this element are rendered using
 * monospace font, and completely unformatted otherwise. Ideal for showing code.
 */
?>

<pre>
<?php print_r( $an_array ) ?>
</pre>

<?php

/*
 * print_r() with JSON/AJAX
 *
 * When using AJAX (which is becoming much more popular), it is not always a good idea to include
 * the debug code in the response. The data returned is not always displayed on the screen, and is
 * more likely to be automatically parsed by the JavaScript JSON library before being made available
 * to the script.
 *
 * It will still work, however, it will definitely not be as useful as our previous example.
 */

?>

<?php print_r( $an_array ) ?>

<?php
/*
 * print_r() with JSON/AJAX and file output
 * 
 * A better way to use print_r() with stuff that is returned directly to JavaScript, is to have PHP
 * generate a file, like a log. The file will be created (unless otherwise specified) in the folder
 * where the PHP script is being run. Using an editor (like Notepad++) which can detect when the
 * file is modified makes it easier to use it as a console window of sorts.
 *
 * PHP usually runs from the root folder of your website - where all your routes and paths start. It
 * is here you can more often than not see the file created. If it's not there, it'll be somewhere
 * in your code. It is helpful to name the file something that is unique, so you can search for it.
 *
 * In order to easily create a file, I use the code below. It is a shortcut to opening a file and
 * writing to it with separate function calls.
 *
 * In this code snippet, you can see that I've added another argument to the print_r() function. I
 * am passing "true" to this function so that it will return the rendered string instead of echoing
 * it to the screen. In this way, you can store the string anywhere for later retrieval. In this
 * case, we are sending the string directly to "logfile.txt".
 *
 * Also of note, the file_put_contents() function also accepts the constant for FILE_APPEND - it
 * simply means that if the file already has stuff in it, this call will add the new information to
 * the end of the file.
 */
?>

<?php file_put_contents( 'logfile.txt', print_r( $an_array, true ), FILE_APPEND ); ?>

<?php
/*
 * print_r() for file output
 * 
 * As I mention above, you can add another argument to the print_r() function that tells it to not
 * echo its string onto the screen. Using the function this way, you can defer output to a file or a
 * file. Also, as long as the script is running you can hold onto that variable until you need it.
 */
?>

<?php $stringified_array = print_r( $an_array, true ); ?>
