<?php
/*
	How PHP 7 Helps II

	Source (and further reading):
	http://php.net/manual/en/migration70.php

	VARIABLE INTERPRETATIONS

	PHP 7 now uses an abstract syntax tree on parsing. Improves consistency, but breaks old code in
	certain cases.
	
	Some examples follow:
	
	INDIRECT VARIABLE INTERPRETATION
*/

//Expression:
$$foo['bar']['baz']

//PHP 5 Equivalent
${$foo['bar']['baz']}

//PHP 7 Equivalent
($$foo)['bar']['baz']



//Expression:
$foo->$bar['baz']

//PHP 5 Equivalent
$foo->{$bar['baz']}

//PHP 7 Equivalent
($foo->$bar)['baz']