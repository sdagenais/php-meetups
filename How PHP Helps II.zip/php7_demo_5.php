<?php
/*
	How PHP 7 Helps II

	Source (and further reading):
	http://php.net/manual/en/migration70.php

	FOREACH

	The foreach loop no longer iterates the internal array pointer. So, you won't be able to see
	where the foreach stopped by checking that pointer.
*/

$array = [0, 1, 2];
foreach ($array as &$val) {
    var_dump(current($array));
}

// On PHP 5, this would print:
/*
int(1)
int(2)
bool(false)
*/



// On PHP 7, this will print:
/*
int(0)
int(0)
int(0)
*/