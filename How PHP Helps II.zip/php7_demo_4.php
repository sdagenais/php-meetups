<?php
/*
	How PHP 7 Helps II

	Source (and further reading):
	http://php.net/manual/en/migration70.php

	VARIABLE INTERPRETATIONS

	PHP 7 now uses an abstract syntax tree on parsing. Improves consistency, but breaks old code in
	certain cases.
	
	Some examples follow:
	
	PARENTHESES FOR FUNCTION PARAMETERS NO LONGER SUPPRESS WARNINGS
	
	Redundant parentheses around a function is able to suppress warnings when passing parameters by
	reference. PHP 7 no longer suppresses warnings from this.
*/

function getArray() {
    return [1, 2, 3];
}

function squareArray(array &$a) {
    foreach ($a as &$v) {
        $v **= 2;
    }
}

// Generates a warning in PHP 7.
squareArray((getArray()));
