<?php
/*
	How PHP 7 Helps II

	Source (and further reading):
	http://php.net/manual/en/migration70.php

	STRING HANDLING

	PHP 7 treats hexadecimal numbers as strings. So, if a string starts with a hexadecimal number,
	and ends with non-hexadecimal characters, the string will not be parsed.
*/

var_dump("0x123" == "291");
var_dump(is_numeric("0x123"));
var_dump("0xe" + "0x1");
var_dump(substr("foo", "0x1"));

// Output in PHP 5
/*
bool(true)
bool(true)
int(15)
string(2) "oo"
*/

// Output in PHP 7
/*
bool(false)
bool(false)
int(0)

Notice: A non well formed numeric value encountered in /tmp/test.php on line 5
string(3) "foo"
*/
