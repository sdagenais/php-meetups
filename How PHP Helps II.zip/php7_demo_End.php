<?php
/*
	How PHP 7 Helps II

	Could not find tools to assist in the upgrade

	Source (and further reading):
	http://php.net/manual/en/migration70.php
	
	http://www.sitepoint.com/php-7-revolution-return-types-removed-artifacts/
	
	For Ubuntu users:
	https://www.digitalocean.com/community/tutorials/how-to-upgrade-to-php-7-on-ubuntu-14-04
	
	O'Reilly:
	http://www.oreilly.com/web-platform/free/upgrading-to-php-seven.csp
	
	Questions?
	
	Further Reading?
*/