<?php
/*
	How PHP 7 Helps II

	Source (and further reading):
	http://php.net/manual/en/migration70.php

	VARIABLE INTERPRETATIONS

	PHP 7 now uses an abstract syntax tree on parsing. Improves consistency, but breaks old code in
	certain cases.
	
	Some examples follow:
	
	LISTS
	
	Lists now assign values to variables in the same order they are defined.
*/

list($a[], $a[], $a[]) = [1, 2, 3];
var_dump($a);

// Output for PHP 5:
/*
array(3) {
  [0]=>
  int(3)
  [1]=>
  int(2)
  [2]=>
  int(1)
}
*/

// Output for PHP 7:
/*
array(3) {
  [0]=>
  int(1)
  [1]=>
  int(2)
  [2]=>
  int(3)
}
*/



// These are no longer allowed (no more empty assignments)
list() = $a;
list(,,) = $a;
list($x, list(), $y) = $a;

