<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Todo;

class TodoController extends Controller
{
	public function index() {
		
		// Get the list of todos:
		$todo = new Todo();

		// Get the list view here
		return view( 'todo.list', [ 'todos' => $todo->get() ] );
	}

    public function add( Request $request ) {

		$todo = new Todo();

		if ( isset( $request->name ) ) {
			$todo->title = $request->name;
			$todo->note = $request->description;
			$todo->save();
			
			return redirect()->route( 'todo' );
		}

		// Add a view to this
		return view( 'todo.add' );
	}
	
	public function edit( Request $request ) {

		$todo = Todo::find( $request->id );

		if ( !isset( $request->id ) ) {
			return redirect()->route( 'todo' );
		}

		if ( isset( $request->name ) ) {
			$todo->title = $request->name;
			$todo->note = $request->description;
			$todo->save();

			return redirect()->route( 'todo' );
		}
		
		// Add a view to this
		return view( 'todo.edit', [ 'todos' => $todo ] );
	}
	
	public function delete( Request $request ) {

		$todo = Todo::find( $request->id );

		if ( !isset( $request->id ) ) {
			return redirect()->route( 'todo' );
		}

		$todo->delete();
		
		// This just requires JSON to be returned
		return redirect()->route( 'todo' );
	}
}
