<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><a href="/home">< Back</a> - Todos</div>
                <div class="panel-body">
					<a href="/todo/add">Add Todo</a>
					<table width="100%">
						<thead>
							<tr>
								<th>Name</th>
								<th>Description</th>
								<th>Actions</th>
							</tr>
						</thead>
						<tbody>
					<?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
							<tr>
								<td><?php echo e($todo->title); ?></td>
								<td><?php echo e($todo->note); ?></td>
								<td class="inline-view">
									<form action="/todo/edit/<?php echo e($todo->id); ?>" method="get">
										<?php echo e(csrf_field()); ?>

										<button>Edit</button>
									</form>
									<form action="/todo/delete/<?php echo e($todo->id); ?>" method="delete">
										<?php echo e(csrf_field()); ?>

										<button>Delete</button>
									</form>
								</td>
							</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
						</tbody>
					</table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>