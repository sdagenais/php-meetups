@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><a href="/home">< Back</a> - Todos</div>
                <div class="panel-body">
					<a href="/todo/add">Add Todo</a>
					<table width="100%">
						<thead>
							<tr>
								<th>Name</th>
								<th>Description</th>
								<th>Actions</th>
							</tr>
						</thead>
						<tbody>
					@foreach( $todos as $todo )
							<tr>
								<td>{{ $todo->title }}</td>
								<td>{{ $todo->note }}</td>
								<td class="inline-view">
									<form action="/todo/edit/{{ $todo->id }}" method="get">
										{{ csrf_field() }}
										<button>Edit</button>
									</form>
									<form action="/todo/delete/{{ $todo->id }}" method="delete">
										{{ csrf_field() }}
										<button>Delete</button>
									</form>
								</td>
							</tr>
					@endforeach
						</tbody>
					</table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection