@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Todos - Edit</div>
                <div class="panel-body">
					<form action="" method="post">
						{{ csrf_field() }}
						<table width="100%">
							<tbody>
								<tr>
									<td>Name: </td>
									<td><input type="text" name="name" value="{{ $todos->title }}" /></td>
								</tr>
								<tr>
									<td>Description: </td>
									<td><input type="text" name="description" value="{{ $todos->note }}" /></td>
								</tr>
								<tr>
									<td colspan="2"><input type="submit" value="Update" /></td>
								</tr>
							</tbody>
						</table>
					</form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection