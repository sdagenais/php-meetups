<!DOCTYPE html>
<html>
    <head>
        <title>PHP Tips and Tricks II</title>
    </head>
    <body>
        <pre>
            <?php

                class People {

                    var $people;

                    public function __construct( $people=[] ) {

                        $this->people = $people;
                    }

                    public function add( $item ) {

                        $this->people[] = $item;
                    }

                    public function eachItem( $function ) {

                        for ( $i = 0; $i < count( $this->people ); $i++ ) {

                            $function( $this->people[ $i ] );
                        }

                        return $this;
                    }

                    public function filter( $function ) {

                        $theNewList = new People();

                        $this->eachItem( function( $item ) use ( $function, &$theNewList ) {

                            if ( $function( $item ) ) {

                                $theNewList->add( $item );
                            }
                        } );

                        return $theNewList;
                    }
                }

                class Person {

                    var $name;
                    var $age;
                    var $phone;
                    var $occupation;

                    public function __construct( $settings ) {

                        $this->name = $settings[ 'name' ];
                        $this->age = $settings[ 'age' ];
                        $this->phone = $settings[ 'phone' ];
                        $this->occupation = 'Clerk';
                    }

                    public function printOccupation() {

                        print_r( sprintf( "%s is a %s!\n", $this->name, $this->occupation ) );
                    }
                }

                class Developer extends Person {

                    public function __construct( $settings ) {

                        parent::__construct( $settings );
                        $this->occupation = 'Developer';
                    }
                }

                class Salesperson extends Person {

                    public function __construct( $settings ) {

                        parent::__construct( $settings );
                        $this->occupation = 'Salesperson';
                    }
                }

                $list[] = new Person( [
                    'name' => 'Jake',
                    'age' => 34,
                    'phone' => '613 888 8888'
                ] );
                $list[] = new Person( [
                    'name' => 'Cale',
                    'age' => 50,
                    'phone' => '613 888 8888'
                ] );
                $list[] = new Person( [
                    'name' => 'Wayne',
                    'age' => 24,
                    'phone' => '613 848 2342'
                ] );
                $list[] = new Person( [
                    'name' => 'Janet',
                    'age' => 21,
                    'phone' => '613 234 1232'
                ] );
                $list[] = new Developer( [
                    'name' => 'Paul',
                    'age' => 35,
                    'phone' => '613 668 8833'
                ] );
                $list[] = new Salesperson( [
                    'name' => 'Cobourg',
                    'age' => 62,
                    'phone' => '613 450 3499'
                ] );
                $list[] = new Person( [
                    'name' => 'Elton',
                    'age' => 19,
                    'phone' => '613 700 3343'
                ] );
                $list[] = new Person( [
                    'name' => 'Sammie',
                    'age' => 34,
                    'phone' => '613 111 1111'
                ] );

                $collection = new People( $list );

                // We now have 9 lines of code, less than a 3rd of the starting lines.
                // Of course, we moved a lot of code above this, however, we can now read this code a lot better.
                function refactorable( $list ) {

                    // Finally, we can chain all the function calls, and get rid of that second array's declaration.
                    $list->eachItem( function ( $item ) {

                        $item->printOccupation();
                    } )->filter( function ( $item ) {

                        return $item->age > 26;
                    } )->eachItem( function ( $item ) {

                        print_r( $item );
                    } );
                }

                refactorable( $collection );
            ?>
        </pre>
    </body>
</html>