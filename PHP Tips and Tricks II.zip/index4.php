<!DOCTYPE html>
<html>
    <head>
        <title>PHP Tips and Tricks II</title>
    </head>
    <body>
        <pre>
            <?php

                class Person {

                    var $name;
                    var $age;
                    var $phone;
                    var $occupation;

                    public function __construct( $settings ) {

                        $this->name = $settings[ 'name' ];
                        $this->age = $settings[ 'age' ];
                        $this->phone = $settings[ 'phone' ];
                        $this->occupation = '';
                    }

                    public function printOccupation() {

                        print_r( sprintf( "%s is a %s!\n", $this->name, $this->occupation ) );
                    }
                }

                $list[] = new Person( [
                    'name' => 'Jake',
                    'age' => 34,
                    'phone' => '613 888 8888'
                ] );
                $list[] = new Person( [
                    'name' => 'Cale',
                    'age' => 50,
                    'phone' => '613 888 8888'
                ] );
                $list[] = new Person( [
                    'name' => 'Wayne',
                    'age' => 24,
                    'phone' => '613 848 2342'
                ] );
                $list[] = new Person( [
                    'name' => 'Janet',
                    'age' => 21,
                    'phone' => '613 234 1232'
                ] );
                $list[] = new Person( [
                    'name' => 'Paul',
                    'age' => 35,
                    'phone' => '613 668 8833'
                ] );
                $list[] = new Person( [
                    'name' => 'Cobourg',
                    'age' => 62,
                    'phone' => '613 450 3499'
                ] );
                $list[] = new Person( [
                    'name' => 'Elton',
                    'age' => 19,
                    'phone' => '613 700 3343'
                ] );
                $list[] = new Person( [
                    'name' => 'Sammie',
                    'age' => 34,
                    'phone' => '613 111 1111'
                ] );

                // We can use anonymous functions to hide the for loop
                function eachItem( $theArray, $function ) {

                    for ( $i = 0; $i < count( $theArray ); $i++ ) {

                        // We pass in the current element, and if we want to modify the array, pass in the whole array
                        $function( $theArray[ $i ] );
                    }
                }

                function refactorable( $list ) {

                    // Now, instead of worrying about how we're going to loop through our list, we just make function
                    // call and pass it an anonymous function.
                    eachItem( $list, function ( $item ) {

                        switch( $item->name ) {

                            case 'Cobourg':

                                $item->occupation = 'Salesperson';
                                break;

                            case 'Paul':

                                $item->occupation = 'Developer';
                                break;

                            default:

                                $item->occupation = 'Clerk';
                        };

                        $item->printOccupation();
                    } );

                    $list_copy = [];
                    $list_copy[] = '1';

                    // We can even replace the while loop.
                    // And, using closures we can modify an outside variable through the anonymous function, allowing us
                    // to use the new looping function.
                    eachItem( $list, function ( $item ) use ( &$list_copy ) {


                        if ( $item->age > 26 ) {

                            $list_copy[] = $item;
                        }
                    } );

                    eachItem( $list_copy, function ( $item ) {

                        print_r( $item );
                    } );
                }

                refactorable( $list );
            ?>
        </pre>
    </body>
</html>