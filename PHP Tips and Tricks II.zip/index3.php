<!DOCTYPE html>
<html>
    <head>
        <title>PHP Tips and Tricks II</title>
    </head>
    <body>
        <pre>
            <?php
                // The class, as you may already be familiar with, groups functionality into a logical unit
                class Person {

                    var $name;
                    var $age;
                    var $phone;
                    var $occupation;

                    public function __construct( $settings ) {

                        $this->name = $settings[ 'name' ];
                        $this->age = $settings[ 'age' ];
                        $this->phone = $settings[ 'phone' ];
                        $this->occupation = '';
                    }

                    public function printOccupation() {

                        print_r( sprintf( "%s is a %s!\n", $this->name, $this->occupation ) );
                    }
                }

                // Unfortunately, the list is still an array.
                $list[] = new Person( [
                    'name' => 'Jake',
                    'age' => 34,
                    'phone' => '613 888 8888'
                ] );
                $list[] = new Person( [
                    'name' => 'Cale',
                    'age' => 50,
                    'phone' => '613 888 8888'
                ] );
                $list[] = new Person( [
                    'name' => 'Wayne',
                    'age' => 24,
                    'phone' => '613 848 2342'
                ] );
                $list[] = new Person( [
                    'name' => 'Janet',
                    'age' => 21,
                    'phone' => '613 234 1232'
                ] );
                $list[] = new Person( [
                    'name' => 'Paul',
                    'age' => 35,
                    'phone' => '613 668 8833'
                ] );
                $list[] = new Person( [
                    'name' => 'Cobourg',
                    'age' => 62,
                    'phone' => '613 450 3499'
                ] );
                $list[] = new Person( [
                    'name' => 'Elton',
                    'age' => 19,
                    'phone' => '613 700 3343'
                ] );
                $list[] = new Person( [
                    'name' => 'Sammie',
                    'age' => 34,
                    'phone' => '613 111 1111'
                ] );

                function refactorable( $list ) {

                    for ( $i = 0; $i < count( $list ); $i++ ) {

                        switch( $list[ $i ]->name ) {

                            case 'Cobourg':

                                $list[ $i ]->occupation = 'Salesperson';
                                break;

                            case 'Paul':

                                $list[ $i ]->occupation = 'Developer';
                                break;

                            default:

                                $list[ $i ]->occupation = 'Clerk';
                        };

                        // Just a little shorter now that we have the function in our class
                        // And the namespace is a little cleaner to boot
                        $list[ $i ]->printOccupation();
                    }

                    $i = 0;
                    $list_copy = $list;

                    while( $i < count( $list ) ) {

                        if ( $list[ $i ]->age > 26 ) {

                            $list_copy[] = $list[ $i ];
                        }

                        $i++;
                    }

                    $i = 0;

                    while ( $i < count( $list_copy ) ) {

                        print_r( $list_copy[ $i ] );

                        $i++;
                    }
                }

                refactorable( $list );
            ?>
        </pre>
    </body>
</html>