<!DOCTYPE html>
<html>
    <head>
        <title>PHP Tips and Tricks II</title>
    </head>
    <body>
        <pre>
            <?php

                class People {

                    var $people;

                    public function __construct( $people=[] ) {

                        $this->people = $people;
                    }

                    // New accessor function
                    public function add( $item ) {

                        $this->people[] = $item;
                    }

                    // We reduce the amount of arguments since we have access to the people array.
                    public function eachItem( $function ) {

                        for ( $i = 0; $i < count( $this->people ); $i++ ) {

                            $function( $this->people[ $i ] );
                        }

                        // We can also return ourselves, in order to chain our steps.
                        return $this;
                    }

                    public function filter( $function ) {

                        $theNewList = new People();

                        // The closure still works because of early binding
                        $this->eachItem( function( $item ) use ( $function, &$theNewList ) {

                            if ( $function( $item ) ) {

                                $theNewList->add( $item );
                            }
                        } );

                        // Don't return ourselves, but return new array, so we can operate on that.
                        return $theNewList;
                    }
                }

                class Person {

                    var $name;
                    var $age;
                    var $phone;
                    var $occupation;

                    public function __construct( $settings ) {

                        $this->name = $settings[ 'name' ];
                        $this->age = $settings[ 'age' ];
                        $this->phone = $settings[ 'phone' ];
                        $this->occupation = '';
                    }

                    public function printOccupation() {

                        print_r( sprintf( "%s is a %s!\n", $this->name, $this->occupation ) );
                    }
                }

                $list[] = new Person( [
                    'name' => 'Jake',
                    'age' => 34,
                    'phone' => '613 888 8888'
                ] );
                $list[] = new Person( [
                    'name' => 'Cale',
                    'age' => 50,
                    'phone' => '613 888 8888'
                ] );
                $list[] = new Person( [
                    'name' => 'Wayne',
                    'age' => 24,
                    'phone' => '613 848 2342'
                ] );
                $list[] = new Person( [
                    'name' => 'Janet',
                    'age' => 21,
                    'phone' => '613 234 1232'
                ] );
                $list[] = new Person( [
                    'name' => 'Paul',
                    'age' => 35,
                    'phone' => '613 668 8833'
                ] );
                $list[] = new Person( [
                    'name' => 'Cobourg',
                    'age' => 62,
                    'phone' => '613 450 3499'
                ] );
                $list[] = new Person( [
                    'name' => 'Elton',
                    'age' => 19,
                    'phone' => '613 700 3343'
                ] );
                $list[] = new Person( [
                    'name' => 'Sammie',
                    'age' => 34,
                    'phone' => '613 111 1111'
                ] );

                // Make our new list.
                $collection = new People( $list );

                function refactorable( $list ) {

                    // Now we can call our functions on the collection
                    $list->eachItem( function ( $item ) {

                        switch( $item->name ) {

                            case 'Cobourg':

                                $item->occupation = 'Salesperson';
                                break;

                            case 'Paul':

                                $item->occupation = 'Developer';
                                break;

                            default:

                                $item->occupation = 'Clerk';
                        };

                        $item->printOccupation();
                    } );

                    // A little shorter
                    $list_copy = $list->filter( function ( $item ) {

                        return $item->age > 26;
                    } );

                    $list_copy->eachItem( function ( $item ) {

                        print_r( $item );
                    } );
                }

                refactorable( $collection );
            ?>
        </pre>
    </body>
</html>