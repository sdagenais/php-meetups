<!DOCTYPE html>
<html>
    <head>
        <title>PHP Tips and Tricks II</title>
    </head>
    <body>
        <pre>
            <?php

                class Person {

                    var $name;
                    var $age;
                    var $phone;
                    var $occupation;

                    public function __construct( $settings ) {

                        $this->name = $settings[ 'name' ];
                        $this->age = $settings[ 'age' ];
                        $this->phone = $settings[ 'phone' ];
                        $this->occupation = '';
                    }

                    public function printOccupation() {

                        print_r( sprintf( "%s is a %s!\n", $this->name, $this->occupation ) );
                    }
                }

                $list[] = new Person( [
                    'name' => 'Jake',
                    'age' => 34,
                    'phone' => '613 888 8888'
                ] );
                $list[] = new Person( [
                    'name' => 'Cale',
                    'age' => 50,
                    'phone' => '613 888 8888'
                ] );
                $list[] = new Person( [
                    'name' => 'Wayne',
                    'age' => 24,
                    'phone' => '613 848 2342'
                ] );
                $list[] = new Person( [
                    'name' => 'Janet',
                    'age' => 21,
                    'phone' => '613 234 1232'
                ] );
                $list[] = new Person( [
                    'name' => 'Paul',
                    'age' => 35,
                    'phone' => '613 668 8833'
                ] );
                $list[] = new Person( [
                    'name' => 'Cobourg',
                    'age' => 62,
                    'phone' => '613 450 3499'
                ] );
                $list[] = new Person( [
                    'name' => 'Elton',
                    'age' => 19,
                    'phone' => '613 700 3343'
                ] );
                $list[] = new Person( [
                    'name' => 'Sammie',
                    'age' => 34,
                    'phone' => '613 111 1111'
                ] );

                function eachItem( $theArray, $function ) {

                    for ( $i = 0; $i < count( $theArray ); $i++ ) {

                        $function( $theArray[ $i ] );
                    }
                }

                // Added the filter function so that we can reduce our list based on a conditional.
                function filter( $theArray, $function ) {

                    $theNewList = [];

                    // Reusing code here
                    eachItem( $theArray, function( $item ) use ( $function, &$theNewList ) {

                        if ( $function( $item ) ) {

                            $theNewList[] = $item;
                        }
                    } );

                    return $theNewList;
                }

                function refactorable( $list ) {

                    eachItem( $list, function ( $item ) {

                        switch( $item->name ) {

                            case 'Cobourg':

                                $item->occupation = 'Salesperson';
                                break;

                            case 'Paul':

                                $item->occupation = 'Developer';
                                break;

                            default:

                                $item->occupation = 'Clerk';
                        };

                        $item->printOccupation();
                    } );

                    // Now we can use a shorter call here to make our copy of the array.
                    $list_copy = filter( $list, function ( $item ) {

                        // Less bracket nesting
                        return $item->age > 26;
                    } );

                    eachItem( $list_copy, function ( $item ) {

                        print_r( $item );
                    } );
                }

                refactorable( $list );
            ?>
        </pre>
    </body>
</html>