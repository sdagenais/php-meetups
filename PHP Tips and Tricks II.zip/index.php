<!DOCTYPE html>
<html>
    <head>
        <title>PHP Tips and Tricks II</title>
    </head>
    <body>
        <pre>
            <?php
                $list = [
                    [
                        'name' => 'Jake',
                        'age' => 34,
                        'phone' => '613 888 8888'
                    ],
                    [
                        'name' => 'Cale',
                        'age' => 50,
                        'phone' => '613 888 8888'
                    ],
                    [
                        'name' => 'Wayne',
                        'age' => 24,
                        'phone' => '613 848 2342'
                    ],
                    [
                        'name' => 'Janet',
                        'age' => 21,
                        'phone' => '613 234 1232'
                    ],
                    [
                        'name' => 'Paul',
                        'age' => 35,
                        'phone' => '613 668 8833'
                    ],
                    [
                        'name' => 'Cobourg',
                        'age' => 62,
                        'phone' => '613 450 3499'
                    ],
                    [
                        'name' => 'Elton',
                        'age' => 19,
                        'phone' => '613 700 3343'
                    ],
                    [
                       'name' => 'Sammie',
                        'age' => 34,
                        'phone' => '613 111 1111'
                    ]
                ];

                function developer( $person ) {

                    print_r( sprintf( "%s is a Developer!\n", $person[ 'name' ] ) );
                }

                function salesperson( $person ) {

                    print_r( sprintf( "%s is a Salesperson!\n", $person[ 'name' ] ) );
                }

                function clerk( $person ) {

                    print_r( sprintf( "%s is a Clerk!\n", $person[ 'name' ] ) );
                }

                // We start with 30 lines of code
                function refactorable( $list, $list_filter ) {

                    for ( $i = 0; $i < count( $list ); $i++ ) {

                        switch( $list[ $i ][ 'name' ] ) {

                            case 'Cobourg':

                                $list[ $i ][ 'occupation' ] = 'Salesperson';
                                salesperson( $list[ $i ]);
                                break;

                            case 'Paul':

                                $list[ $i ][ 'occupation' ] = 'Developer';
                                developer( $list[ $i ]);
                                break;

                            default:

                                $list[ $i ][ 'occupation' ] = 'Clerk';
                                clerk( $list[ $i ]);
                        };
                    }

                    $i = 0;
                    $list_copy = $list;

                    while( $i < count( $list ) ) {

                        if ( $list[ $i ][ 'age' ] > 26 ) {

                            $list_copy[] = $list[ $i ];
                        }

                        $i++;
                    }

                    $i = 0;

                    while ( $i < count( $list_copy ) ) {

                        print_r( $list_copy[ $i ] );

                        $i++;
                    }
                }

                refactorable( $list, [] );
            ?>
        </pre>
    </body>
</html>